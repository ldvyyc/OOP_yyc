#ifndef _PART_
#define _PART_
#include <iostream>
using namespace std;

class Part{
public:
    int numm;
    Part(int i):numm(i){};
};
#endif