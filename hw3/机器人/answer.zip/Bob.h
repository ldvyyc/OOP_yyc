#ifndef _BOB_
#define _BOB_
#include "Robot.h"
#include <iostream>

class Bob: public Robot{
public:
    using Robot::Robot; 
    int run();
    friend ostream &operator<<(ostream &out, Bob &B);

};
#endif