#ifndef _ROBOT_
#define _ROBOT_
#include "Part.h"
class Robot{
public:
    int num;
    int count;//计数
    int* hhh;
    Robot(int i);
    bool is_full();
    void add_part(Part &&A);
};

#endif