#include "Robot.h"
#include "Alice.h"
#include <iostream>
using namespace std;

int Alice::run(){
    int a=0;
    for (int i=0;i<num;i++){
        a+=hhh[i];
    }
    return a;
}

ostream &operator<<(ostream &out, Alice &A){
    out << "Build robot Alice";
    return out;
};