#ifndef _ALICE_
#define _ALICE_
#include "Robot.h"
#include <iostream>

class Alice: public Robot{
public:
    using Robot::Robot;
    int run();
    friend ostream &operator<<(ostream &out, Alice &A);

};
#endif