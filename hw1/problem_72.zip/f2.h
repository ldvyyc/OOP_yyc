// f2.h
#if !defined(__F2_H__)
#define __F2_H__
#if defined(__F2__)
extern int f2(int a, int b);
#endif /*__F2__*/
#endif /*__F2_H__*/