#include "f4.h"
int f4(int a, int b)
{
	return (a + b) * 2021 + 4;
}

