#ifndef COW_H
#define COW_H
using namespace std;

class Cow
{
public:
    string name;
    int l,u,m;
    Cow(string name1,int l1,int u1,int m1);
    
};

#endif
