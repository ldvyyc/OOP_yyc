#include "Cow.h"
#include <string>
using namespace std;
Cow::Cow(string name, int l, int u, int m){
    name1=name;
    l1=l;
    u1=u;
    m1=m;
}