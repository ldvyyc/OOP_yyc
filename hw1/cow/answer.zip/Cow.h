#ifndef Cow_h
#define Cow_h
#include <string>
using namespace std;
class Cow {
public:
    string name1;
    int l1;
    int u1;
    int m1;
    Cow(string name, int l, int u, int m);
};
#endif